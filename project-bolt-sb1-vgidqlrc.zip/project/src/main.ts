import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  template: `
    <div class="page-container">
      <!-- Contact Information Section -->
      <section class="contact-container">
        <div class="company-header">
          <h1 class="company-name">CleanPro Services</h1>
          <p class="company-tagline">Servicii profesionale de curățenie și dezinfecție</p>
        </div>
        
        <div class="contact-details-grid">
          <div class="contact-item">
            <div class="contact-icon">📞</div>
            <div class="contact-info">
              <span class="contact-label">Telefon</span>
              <span class="contact-value">+40 721 234 567</span>
            </div>
          </div>
          
          <div class="contact-item">
            <div class="contact-icon">📧</div>
            <div class="contact-info">
              <span class="contact-label">Email</span>
              <span class="contact-value">contact&#64;cleanpro.ro</span>
            </div>
          </div>
          
          <div class="contact-item">
            <div class="contact-icon">📍</div>
            <div class="contact-info">
              <span class="contact-label">Adresa</span>
              <span class="contact-value">Str. Curățeniei nr. 123, București</span>
            </div>
          </div>
          
          <div class="contact-item">
            <div class="contact-icon">🕒</div>
            <div class="contact-info">
              <span class="contact-label">Program</span>
              <span class="contact-value">Luni - Vineri: 8:00 - 18:00</span>
            </div>
          </div>
        </div>
      </section>

      <!-- Services Section -->
      <section class="services-container">
        <h2 class="services-title">Serviciile Noastre</h2>
        
        <div class="services-grid">
          <!-- Dezinsectie Service -->
          <div class="service-card">
            <div class="service-icon">🐛</div>
            <h3 class="service-title">Dezinsecție</h3>
            <p class="service-description">
              Oferim servicii complete de dezinsecție pentru eliminarea eficientă a insectelor dăunătoare din locuințe și spații comerciale. Utilizăm produse profesionale, sigure pentru sănătate și mediu, cu eficiență de lungă durată. Echipa noastră experimentată garantează rezultate rapide și durabile împotriva furnicilor, gândacilor, țânțarilor și altor insecte nedorite.
            </p>
            <div class="service-features">
              <span class="feature-tag">Tratament profesional</span>
              <span class="feature-tag">Produse ecologice</span>
              <span class="feature-tag">Garanție 6 luni</span>
            </div>
          </div>

          <!-- Dezinfectie Service -->
          <div class="service-card">
            <div class="service-icon">🧼</div>
            <h3 class="service-title">Dezinfecție</h3>
            <p class="service-description">
              Servicii profesionale de dezinfecție pentru eliminarea bacteriilor, virusurilor și microorganismelor patogene. Aplicăm protocoale sanitare riguroase, conform standardelor internaționale de sănătate publică. Ideal pentru spații medicale, birouri, restaurante și locuințe, oferind protecție completă pentru familia sau echipa dumneavoastră.
            </p>
            <div class="service-features">
              <span class="feature-tag">Certificat medical</span>
              <span class="feature-tag">Tehnologii avansate</span>
              <span class="feature-tag">Disponibil 24/7</span>
            </div>
          </div>

          <!-- Deratizare Service -->
          <div class="service-card">
            <div class="service-icon">🐭</div>
            <h3 class="service-title">Deratizare</h3>
            <p class="service-description">
              Soluții eficiente pentru controlul și eliminarea rozătoarelor din mediul dumneavoastră. Utilizăm metode moderne și sigure pentru combaterea șoarecilor, șobolanilor și altor rozătoare dăunătoare. Oferim atât tratamente punctuale, cât și programe de mentenanță periodică pentru prevenirea reinfestărilor și menținerea unui mediu curat și sanitar.
            </p>
            <div class="service-features">
              <span class="feature-tag">Metode sigure</span>
              <span class="feature-tag">Monitoring continuu</span>
              <span class="feature-tag">Rezultate garantate</span>
            </div>
          </div>
        </div>
      </section>

      <!-- Call to Action Section -->
      <section class="cta-container">
        <h2 class="cta-title">Contactați-ne pentru o consultație gratuită</h2>
        <p class="cta-description">Echipa noastră de specialiști vă stă la dispoziție pentru a oferi soluții personalizate</p>
        <button class="cta-button" (click)="contactUs()">Solicită Ofertă</button>
      </section>
    </div>
  `,
  styles: [`
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .page-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #334155;
    }

    /* Contact Container Styles */
    .contact-container {
      background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
      color: white;
      padding: 4rem 2rem;
      text-align: center;
    }

    .company-header {
      margin-bottom: 3rem;
    }

    .company-name {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 1rem;
      letter-spacing: -0.02em;
    }

    .company-tagline {
      font-size: 1.25rem;
      opacity: 0.9;
      font-weight: 300;
    }

    .contact-details-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 2rem;
      max-width: 1200px;
      margin: 0 auto;
    }

    .contact-item {
      display: flex;
      align-items: center;
      background: rgba(255, 255, 255, 0.1);
      padding: 1.5rem;
      border-radius: 12px;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      transition: all 0.3s ease;
    }

    .contact-item:hover {
      transform: translateY(-2px);
      background: rgba(255, 255, 255, 0.15);
    }

    .contact-icon {
      font-size: 2rem;
      margin-right: 1rem;
    }

    .contact-info {
      display: flex;
      flex-direction: column;
      text-align: left;
    }

    .contact-label {
      font-size: 0.9rem;
      opacity: 0.8;
      font-weight: 500;
    }

    .contact-value {
      font-size: 1.1rem;
      font-weight: 600;
    }

    /* Services Container Styles */
    .services-container {
      padding: 5rem 2rem;
      max-width: 1400px;
      margin: 0 auto;
    }

    .services-title {
      text-align: center;
      font-size: 2.5rem;
      font-weight: 700;
      color: #1e40af;
      margin-bottom: 4rem;
      position: relative;
    }

    .services-title::after {
      content: '';
      position: absolute;
      bottom: -1rem;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 4px;
      background: #2563eb;
      border-radius: 2px;
    }

    .services-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(380px, 1fr));
      gap: 2.5rem;
    }

    .service-card {
      background: white;
      padding: 2.5rem;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(37, 99, 235, 0.1);
      transition: all 0.3s ease;
      border: 1px solid #e2e8f0;
    }

    .service-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 20px 40px rgba(37, 99, 235, 0.15);
      border-color: #2563eb;
    }

    .service-icon {
      font-size: 3rem;
      margin-bottom: 1.5rem;
      text-align: center;
    }

    .service-title {
      font-size: 1.75rem;
      font-weight: 700;
      color: #1e40af;
      margin-bottom: 1.5rem;
      text-align: center;
    }

    .service-description {
      font-size: 1rem;
      line-height: 1.7;
      color: #475569;
      margin-bottom: 2rem;
      text-align: justify;
    }

    .service-features {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
      justify-content: center;
    }

    .feature-tag {
      background: linear-gradient(135deg, #2563eb, #1d4ed8);
      color: white;
      padding: 0.5rem 1rem;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 500;
    }

    /* CTA Container Styles */
    .cta-container {
      background: linear-gradient(135deg, #1e40af 0%, #1d4ed8 100%);
      color: white;
      padding: 4rem 2rem;
      text-align: center;
    }

    .cta-title {
      font-size: 2.25rem;
      font-weight: 700;
      margin-bottom: 1rem;
    }

    .cta-description {
      font-size: 1.125rem;
      opacity: 0.9;
      margin-bottom: 2.5rem;
      max-width: 600px;
      margin-left: auto;
      margin-right: auto;
    }

    .cta-button {
      background: white;
      color: #1e40af;
      border: none;
      padding: 1rem 2.5rem;
      border-radius: 50px;
      font-size: 1.125rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .cta-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
      background: #f8fafc;
    }

    .cta-button:active {
      transform: translateY(0);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .company-name {
        font-size: 2.25rem;
      }

      .company-tagline {
        font-size: 1rem;
      }

      .contact-details-grid {
        grid-template-columns: 1fr;
      }

      .services-grid {
        grid-template-columns: 1fr;
      }

      .service-card {
        padding: 2rem;
      }

      .services-title {
        font-size: 2rem;
      }

      .cta-title {
        font-size: 1.75rem;
      }

      .contact-container,
      .services-container,
      .cta-container {
        padding: 3rem 1.5rem;
      }
    }

    @media (max-width: 480px) {
      .company-name {
        font-size: 1.875rem;
      }

      .contact-item {
        padding: 1.25rem;
      }

      .service-card {
        padding: 1.5rem;
      }

      .contact-container,
      .services-container,
      .cta-container {
        padding: 2.5rem 1rem;
      }
    }
  `]
})
export class App {
  contactUs() {
    // This would typically open a contact form or redirect to a contact page
    alert('Vă mulțumim pentru interesul acordat! Vă vom contacta în cel mai scurt timp posibil.');
  }
}

bootstrapApplication(App);